<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-facteur?lang_cible=pt_br
// ** ne pas modifier le fichier **

return [

	// F
	'facteur_description' => 'O Carteiro cuida da distribuição de e-mails no formato HTML, texto ou misto; via SMTP ou não',
	'facteur_nom' => 'Carteiro',
	'facteur_slogan' => 'Distribui os seus e-mails',
];
